# PayVault

A local, offline "friction gate" for your payment apps. Instead of a PIN, you type
what the payment is for — the app then unlocks (launches) the real payment app for
you to complete the payment manually.

## What it does

1. You pick which apps (PhonePe, GPay, Paytm, ...) live behind the vault.
2. Tapping a vault tile opens a form: **Amount, Type, Category, Person/Merchant
   (optional), Note (optional)**.
3. On Submit, the entry is saved locally, then the real app is launched — the same
   as tapping its own icon.
4. PayVault does nothing else. It doesn't watch the screen, read notifications,
   access your bank, or know whether the payment happened.
5. A Monthly view shows totals, spend by type, category breakdown, top categories,
   and full transaction history — all computed from what you typed in, nothing else.

## What it deliberately does NOT do

- No `INTERNET` permission at all — the app *cannot* send data anywhere, by
  construction, not just by promise.
- No accessibility service, no notification listener, no usage-stats access, no
  device-admin/MDM APIs.
- No reading of the target app's UI, clipboard, notifications, or storage.
- No verification that a payment actually happened — it can't know, and doesn't try.

## Important: the real limitation on "hiding" apps

Android does **not** let a normal app hide another app's home-screen icon or
app-drawer entry. That capability is restricted to:
- The device's **default launcher** (a full launcher replacement app), or
- **Device-owner / MDM** provisioning (`DevicePolicyManager.setApplicationHidden`),
  which requires enterprise device management setup — not realistic for a personal
  phone.

PayVault is a normal app, not a launcher replacement, so it uses the closest
practical, fully-supported approach instead:

- **PayVault becomes the front door.** You add PhonePe/GPay/etc. as vault tiles.
  PayVault launches them via the standard public launch-intent API
  (`PackageManager.getLaunchIntentForPackage`) — identical to tapping their icon.
- **You manually remove the payment apps' icons from your home screen** (drag to
  "Remove from Home", not uninstall) after adding them to the vault, and access them
  only through PayVault going forward. Many launchers (Nova, Samsung One UI, MIUI)
  also have a native "Hide apps" feature in their own settings — if yours does, use
  that for the app-drawer entry too. This is a manual one-time step; no code can do
  it for you from inside a regular app.
- **Optional: disguise PayVault itself.** `AndroidManifest.xml` includes a commented-out
  `activity-alias` example that lets PayVault change *its own* icon/label (e.g. to
  look like "Notes"). This only touches PayVault's own components via the public
  `PackageManager.setComponentEnabledSetting` API — see `AppUtils.setDisguiseEnabled()`.
- **Recents/App-switcher:** after a payment app is launched, consider swiping it away
  from Recents when done, since a screenshot of it may still appear there — this is
  normal OS behavior for any app and not something PayVault can suppress for another app.

If true system-wide icon hiding matters more to you than the "type before you pay"
gate, the next step up would be building a full launcher replacement (a much bigger
project — happy to scope that separately if you want it).

## AI Quick Entry (optional, local-only, instant)

The vault home screen has an **"AI Quick Entry"** card. Tap it, type one short
Hindi/Hinglish phrase the way you'd actually say it — shorthand is fine, full
sentences aren't needed — and it:

1. Parses the phrase locally.
2. **Saves the entry immediately** — no review/edit screen, no confirmation prompt.
3. Takes you straight to a **"choose app"** screen listing your vault apps.
4. You tap PhonePe/GPay/whichever, it opens, and you pay yourself, exactly as with
   manual entry — the AI never touches the payment itself.

```
"500 khana"                -> Expense / Food
"100 Amit ko diye"         -> Lent    / Amit
"100 ghar diye"            -> Family
"500 ka dhoodh laya"       -> Expense / Grocery
"500 ki kitab laya"        -> Expense / Books
"900 ka recharge kiya"     -> Expense / Recharge
"1200 gym ki fees"         -> Expense / Fitness
"850 petrol"               -> Expense / Fuel
"2k gift diya"             -> Gift    / (2000)
```

**No stopping to ask.** If a phrase is ambiguous, the parser never blocks or asks a
follow-up — it falls back to `Type = Expense`, `Category = Other` and continues, per
the design brief. The one thing it *will* refuse to do is save an entry with no
amount at all (e.g. you typed only "khana" with no number) — that's a basic sanity
check, not a confirmation step, and it just asks you to include a number and try
again.

**Manual entry is untouched and still separate.** Tapping a vault app tile still
opens the full keypad/pills/category-grid form exactly as before, with its own
Submit button — nothing about that path changed. AI Quick Entry is purely an
additional, optional shortcut reached from its own card on the home screen.

**How it works — rule-based, not a model.** `nlp/QuickEntryParser.kt` is a small
Kotlin object with three parts:
- **Normalization** — lowercase, strip `₹`/commas, collapse whitespace.
- **Amount extraction** — handles shorthand (`2k`, `1.5k` → thousands), Hindi number
  words (`2 hazar`, `2 hazar 500`, `5 sau`), plain digits, and optional `Rs`/`INR`
  markers.
- **Vocabulary + rules** — Hindi/Hinglish keyword lists (with common spelling
  variants like `doodh`/`dhoodh`/`dudh`, `kitab`/`kitaab`) drive Type (Lent > Gift >
  Family > Saving, else a "`<Name> ko ... diya`" giving-pattern → Lent, else Expense)
  and Category (a ~50-entry keyword → category dictionary, e.g. `petrol`→Fuel,
  `gym`→Fitness, `recharge`→Recharge, with `ghar`/family words → Family and a final
  `Other` fallback so nothing is ever left unclassified). Person is extracted from
  the common "`<Name> ko`" dative pattern.

That's the whole implementation — no ML runtime, no model weights, nothing to
download or update.

**Why not an actual on-device LLM:** a genuinely useful local language model — even a
small quantized one — needs a native inference runtime (llama.cpp/GGUF, MediaPipe
LLM, ONNX Runtime, etc.) plus tens to hundreds of MB of model weights bundled into
the APK. That's a large jump in app size and complexity for a feature whose whole job
is extracting five short fields from a five-word phrase. The brief's own fallback
instruction was to prefer a lightweight offline parser over a large model when a true
local model isn't practical here — so that's what's implemented, tuned for speed and
broad shorthand coverage over linguistic sophistication.

**Size & performance impact:** effectively zero. It's one ~230-line Kotlin file with
a few dictionaries — a few KB added to the APK, no new dependencies, no new
permissions, and parsing a phrase takes well under a millisecond on any phone from
the last decade.

**Privacy:** identical to the rest of the app. The phrase you type is only ever held
in memory long enough to fill in Amount/Type/Category/Person/Note, which are then
written to the same local Room database manual entries use. Since the app still has
no `INTERNET` permission, it's structurally impossible for that text — or anything
derived from it — to leave the device.

**Schema note:** `VaultEntry.targetPackage`/`targetAppLabel` are now nullable, because
a Quick Entry row is saved *before* you pick which app to unlock (`assignTargetApp()`
in `VaultEntryDao` fills them in a moment later, once you tap an app on the picker
screen). If you back out of the picker without choosing an app, the entry stays saved
with no app attached — it still counts toward your monthly totals, and the history
list shows "No app chosen" for it. This bumped the local Room schema to version 2
with a destructive-migration fallback (there's no released version of this app with
real user data to preserve, so a clean recreate is simpler and safer than a
hand-written migration for a nullability-only change).

**Known limitations** (intentionally simple, and everything is still visible/editable
via the manual form if you want to fix something after the fact):
- Person detection only catches the common "`<Name> ko`" pattern with a single-word
  name.
- Amount detection expects digits (optionally with `k`/hazar/sau shorthand) — fully
  spelled-out numbers ("do hazar") aren't recognized.
- The category dictionary is a fixed list, not exhaustive — anything it doesn't
  recognize falls back to `Other`, which you can always change later from the
  monthly view... though note the dashboard itself has no edit UI yet (see the
  "Data" section below) — this is a good candidate for a future addition if you want
  to correct an AI-classified entry after the fact.

## What's new: real UI + home-screen widgets

**UI overhaul.** The form-fill flow is unchanged conceptually, but it no longer looks
like a form:
- A dark "vault" theme (custom color scheme in `ui/theme/Theme.kt`) instead of default
  Material colors.
- Vault tiles show the **real app icon** (read via the public `PackageManager` icon API
  — same icon you'd see on your home screen).
- The entry screen has a big amount readout with its own **number keypad**, animated
  icon "pill" buttons for Type, and an icon grid for Category — closer to a payment
  app's own UI than a settings form.
- The Monthly view now has an actual **progress-bar breakdown by type** and a **donut
  chart** for top categories, drawn with Compose `Canvas`, alongside the transaction list.

**Two home-screen widgets**, built with Jetpack Glance so they share the same data
(Room) as the app:
- **Quick Unlock** — lists up to 4 vault apps; tapping one opens PayVault straight at
  that app's entry form (skipping the tile grid). It never launches the payment app
  itself from the widget — you still have to fill in and submit the form first, so the
  gate isn't bypassed.
- **Monthly Total** — shows this month's running total and top category at a glance;
  tapping it opens the dashboard.

Both widgets refresh automatically right after you save an entry or add an app
(`AppUtils.refreshWidgets()` is called at those points) — no background polling, no
`updatePeriodMillis`, so there's no periodic wake-up battery cost.

To add them: long-press your home screen → Widgets → PayVault → drag either widget out.

## Project structure

```
PayVault/
  app/src/main/java/com/payvault/app/
    MainActivity.kt          – entry point, simple screen-state navigation
    data/Models.kt            – VaultEntry & HiddenApp Room entities, EntryType enum
    data/Daos.kt               – Room DAOs
    data/AppDatabase.kt        – Room database singleton (local file, payvault.db)
    util/AppUtils.kt          – list launchable apps, launch an app, app icons, disguise, widget refresh
    ui/theme/Theme.kt          – dark vault color scheme & typography
    ui/VaultHomeScreen.kt     – tile grid of hidden apps (real icons, month stat header)
    ui/AddHiddenAppScreen.kt  – picker to add an installed app to the vault
    ui/EntryFormScreen.kt     – manual entry: keypad + icon pills/grid → unlock (unchanged path)
    ui/QuickEntryScreen.kt    – AI Quick Entry: instant capture + auto-save, then app picker
    ui/DashboardScreen.kt     – monthly totals, by-type bars, category donut chart, history
    nlp/QuickEntryParser.kt   – local, offline Hindi/Hinglish rule-based parser for AI Quick Entry
    widget/QuickUnlockWidget.kt      – Glance widget: jump straight to an app's form
    widget/MonthlySummaryWidget.kt   – Glance widget: this month's total + top category
```

## Building it

1. Open the `PayVault/` folder in Android Studio (Koala or newer).
2. Let Gradle sync (it will download Compose, Room, KSP — first sync needs internet
   just for Gradle/Maven, the *app itself* never uses network at runtime).
3. Run on a device/emulator with API 26+.
4. First run: tap **+** on the home screen, search for PhonePe/GPay/Paytm, tap Add.
5. Remove those apps' icons from your actual home screen (see limitation above).
6. From then on, open PayVault → tap the app tile → fill the form → Submit → the real
   app opens.

## Data

Everything is stored in a local Room/SQLite database (`payvault.db`) inside the app's
private storage. `android:allowBackup="false"` and explicit `data_extraction_rules.xml`
exclusions mean it's also never swept into Android's automatic cloud backup.

There's currently no export/delete-all UI — easy to add if you want CSV export for the
monthly view or a "wipe all data" button; just ask.
