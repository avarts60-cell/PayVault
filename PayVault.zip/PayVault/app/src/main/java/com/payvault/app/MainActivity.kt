package com.payvault.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.payvault.app.data.AppDatabase
import com.payvault.app.data.HiddenApp
import com.payvault.app.ui.AddHiddenAppScreen
import com.payvault.app.ui.DashboardScreen
import com.payvault.app.ui.EntryFormScreen
import com.payvault.app.ui.VaultHomeScreen
import com.payvault.app.ui.theme.PayVaultTheme
import kotlinx.coroutines.flow.first

/** Which screen is currently showing. Deliberately simple — no nav library needed for 4 screens. */
sealed class Screen {
    data object Home : Screen()
    data object AddApp : Screen()
    data class EntryForm(val target: HiddenApp) : Screen()
    data object Dashboard : Screen()
}

/** What a widget tap is asking the app to open, resolved into a Screen once the DB responds. */
private sealed class DeepLink {
    data class ToEntryForm(val packageName: String) : DeepLink()
    data object ToDashboard : DeepLink()
}

class MainActivity : ComponentActivity() {

    companion object {
        /** Set by the "Quick Unlock" widget to jump straight to a given app's form. */
        const val EXTRA_TARGET_PACKAGE = "com.payvault.app.EXTRA_TARGET_PACKAGE"
        /** Set by the "Monthly Total" widget to jump straight to the dashboard. */
        const val EXTRA_OPEN_DASHBOARD = "com.payvault.app.EXTRA_OPEN_DASHBOARD"
    }

    private var pendingDeepLink by mutableStateOf<DeepLink?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingDeepLink = readDeepLink(intent)
        val db = AppDatabase.get(applicationContext)

        setContent {
            PayVaultTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(
                        db = db,
                        deepLink = pendingDeepLink,
                        onDeepLinkConsumed = { pendingDeepLink = null }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingDeepLink = readDeepLink(intent)
    }

    private fun readDeepLink(intent: Intent?): DeepLink? {
        val pkg = intent?.getStringExtra(EXTRA_TARGET_PACKAGE)
        if (pkg != null) return DeepLink.ToEntryForm(pkg)
        if (intent?.getBooleanExtra(EXTRA_OPEN_DASHBOARD, false) == true) return DeepLink.ToDashboard
        return null
    }
}

@Composable
private fun AppRoot(db: AppDatabase, deepLink: DeepLink?, onDeepLinkConsumed: () -> Unit) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    // A widget tap arrives as a deep link, not a Screen directly — resolve any DB
    // lookups it needs (e.g. package name -> HiddenApp) and then navigate.
    LaunchedEffect(deepLink) {
        when (val link = deepLink) {
            is DeepLink.ToEntryForm -> {
                // getAll() is a Flow; take the first emitted list to resolve once.
                val apps = db.hiddenAppDao().getAll().first()
                apps.firstOrNull { it.packageName == link.packageName }?.let {
                    screen = Screen.EntryForm(it)
                }
            }
            is DeepLink.ToDashboard -> {
                screen = Screen.Dashboard
            }
            null -> Unit
        }
        if (deepLink != null) onDeepLinkConsumed()
    }

    when (val s = screen) {
        is Screen.Home -> VaultHomeScreen(
            hiddenAppDao = db.hiddenAppDao(),
            entryDao = db.vaultEntryDao(),
            onAddApp = { screen = Screen.AddApp },
            onOpenDashboard = { screen = Screen.Dashboard },
            onTileTap = { app -> screen = Screen.EntryForm(app) }
        )

        is Screen.AddApp -> AddHiddenAppScreen(
            hiddenAppDao = db.hiddenAppDao(),
            onDone = { screen = Screen.Home }
        )

        is Screen.EntryForm -> EntryFormScreen(
            target = s.target,
            entryDao = db.vaultEntryDao(),
            onDone = { screen = Screen.Home }
        )

        is Screen.Dashboard -> DashboardScreen(
            entryDao = db.vaultEntryDao(),
            onBack = { screen = Screen.Home }
        )
    }
}
