package com.payvault.app.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.payvault.app.MainActivity
import com.payvault.app.data.AppDatabase
import com.payvault.app.data.HiddenApp
import kotlinx.coroutines.flow.first

private val WidgetBackground = ColorProvider(0xFF181C2E.toInt())
private val WidgetAccent = ColorProvider(0xFF34D399.toInt())
private val WidgetText = ColorProvider(0xFFF3F4F8.toInt())
private val WidgetMuted = ColorProvider(0xFF9BA0B4.toInt())

/**
 * Glance passes data to the activity it launches via typed ActionParameters.Key,
 * not a raw Intent — Glance builds the launch Intent itself and attaches these as
 * extras (extra key == key.name), which is why this matches
 * MainActivity.EXTRA_TARGET_PACKAGE exactly.
 */
private val TargetPackageKey = ActionParameters.Key<String>(MainActivity.EXTRA_TARGET_PACKAGE)

/**
 * A small home-screen widget listing your vault apps. Tapping a row opens PayVault
 * directly at that app's entry form — same gate as tapping the tile inside the app,
 * just one fewer step. It never launches the target payment app itself from the
 * widget; the form still has to be filled in first.
 */
class QuickUnlockWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val hiddenApps = AppDatabase.get(context).hiddenAppDao().getAll().first().take(4)

        provideContent {
            Column(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .background(WidgetBackground)
                    .padding(12.dp)
            ) {
                Text(
                    "PayVault",
                    style = TextStyle(color = WidgetAccent, fontWeight = FontWeight.Bold)
                )
                if (hiddenApps.isEmpty()) {
                    Text("Add an app in PayVault", style = TextStyle(color = WidgetMuted))
                } else {
                    hiddenApps.forEach { app -> WidgetAppRow(app) }
                }
            }
        }
    }
}

@Composable
private fun WidgetAppRow(app: HiddenApp) {
    Row(
        modifier = GlanceModifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable(
                actionStartActivity<MainActivity>(
                    parameters = actionParametersOf(TargetPackageKey to app.packageName)
                )
            ),
        verticalAlignment = Alignment.Vertical.CenterVertically
    ) {
        Text(
            app.displayLabel,
            style = TextStyle(color = WidgetText),
            modifier = GlanceModifier.padding(end = 8.dp)
        )
    }
}

class QuickUnlockWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = QuickUnlockWidget()
}
