package com.payvault.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.payvault.app.data.HiddenApp
import com.payvault.app.data.HiddenAppDao
import com.payvault.app.data.VaultEntry
import com.payvault.app.data.VaultEntryDao
import com.payvault.app.nlp.QuickEntryParser
import com.payvault.app.ui.theme.VaultAccent
import com.payvault.app.ui.theme.VaultAccentSoft
import com.payvault.app.ui.theme.VaultSurfaceRaised
import com.payvault.app.util.AppUtils
import kotlinx.coroutines.launch

/**
 * The fast path: type a short Hindi/Hinglish phrase, it's parsed and saved
 * immediately (no review/edit screen — see QuickEntryParser.kt for the rules),
 * then we move straight to QuickAppPickerScreen so the person picks which app to
 * actually pay with. The AI never opens a payment app or touches a payment itself;
 * it only fills in the log entry that already existed as a manual option.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickEntryCaptureScreen(
    entryDao: VaultEntryDao,
    onSaved: (entryId: Long) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    fun submit() {
        val parsed = QuickEntryParser.parse(text)
        val amount = parsed.amount
        if (amount == null || amount <= 0.0) {
            error = "Couldn't find an amount \u2014 try including a number, e.g. \"500 khana\""
            return
        }
        error = null
        scope.launch {
            val id = entryDao.insert(
                VaultEntry(
                    timestamp = System.currentTimeMillis(),
                    amount = amount,
                    type = parsed.type,
                    category = parsed.category,
                    person = parsed.person,
                    note = parsed.note,
                    targetPackage = null,
                    targetAppLabel = null
                )
            )
            AppUtils.refreshWidgets(context)
            onSaved(id)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Quick Entry") },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Cancel")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = VaultAccent, modifier = Modifier.size(28.dp))
            Text(
                "Type it the way you'd say it",
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                "e.g. \"500 khana\", \"100 Amit ko diye\", \"850 petrol\", \"1200 gym ki fees\". " +
                    "Saves instantly and runs fully on this device \u2014 nothing is sent anywhere.",
                style = MaterialTheme.typography.bodySmall
            )

            OutlinedTextField(
                value = text,
                onValueChange = {
                    text = it
                    error = null
                },
                placeholder = { Text("500 khana") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(focusRequester),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    keyboard?.hide()
                    submit()
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VaultAccent,
                    cursorColor = VaultAccent
                )
            )

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = { submit() },
                enabled = text.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VaultAccent)
            ) {
                Icon(Icons.Filled.FlashOn, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Save & choose app", fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(4.dp))
            Text(
                "Prefer typing amounts and picking options by hand? Go back and tap an app tile instead \u2014 manual entry still works exactly as before.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/**
 * Shown immediately after a Quick Entry save. The entry already exists in the DB;
 * tapping an app here just attaches that app to the entry and opens it — the same
 * "unlock" action as the manual flow's Submit button, just arrived at differently.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickAppPickerScreen(
    entryId: Long,
    hiddenAppDao: HiddenAppDao,
    entryDao: VaultEntryDao,
    onAppOpened: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val apps by hiddenAppDao.getAll().collectAsState(initial = emptyList())
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Saved \u2014 choose an app") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = VaultAccentSoft),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    "Logged. Now pick which app you'll pay with \u2014 you still make the payment yourself.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = VaultAccent
                )
            }

            error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            if (apps.isEmpty()) {
                Text(
                    "No apps in the vault yet \u2014 add one from the home screen first.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(apps, key = { it.packageName }) { app ->
                        QuickPickerTile(app = app, onClick = {
                            scope.launch {
                                entryDao.assignTargetApp(entryId, app.packageName, app.realLabel)
                                AppUtils.refreshWidgets(context)
                                val launched = AppUtils.launchApp(context, app.packageName)
                                if (!launched) {
                                    error = "Could not open ${app.realLabel}. It may have been uninstalled."
                                } else {
                                    onAppOpened()
                                }
                            }
                        })
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickPickerTile(app: HiddenApp, onClick: () -> Unit) {
    val context = LocalContext.current
    val icon = produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, key1 = app.packageName) {
        value = AppUtils.getAppIcon(context, app.packageName)
    }.value

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = VaultSurfaceRaised),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                if (icon != null) {
                    Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(28.dp))
                } else {
                    Text(app.displayLabel.take(1).uppercase())
                }
            }
            Text(app.displayLabel, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        }
    }
}
