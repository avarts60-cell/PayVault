package com.payvault.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [VaultEntry::class, HiddenApp::class],
    version = 2, // v2: targetPackage/targetAppLabel became nullable for AI Quick Entry's
                 // "save now, pick the app a moment later" flow.
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vaultEntryDao(): VaultEntryDao
    abstract fun hiddenAppDao(): HiddenAppDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    // Local file only. No INTERNET permission exists in this app,
                    // so this database can never leave the device over the network.
                    "payvault.db"
                )
                    // No formal migration path is defined for the v1 -> v2 column
                    // nullability change; this project has no released schema to
                    // preserve, so a destructive fallback (recreate the DB) is the
                    // simplest correct choice here rather than hand-writing a
                    // Migration for a change that has no real users yet.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
