package com.payvault.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.payvault.app.data.EntryType
import com.payvault.app.data.HiddenApp
import com.payvault.app.data.VaultEntry
import com.payvault.app.data.VaultEntryDao
import com.payvault.app.nlp.QuickEntryParser
import com.payvault.app.ui.theme.VaultAccent
import com.payvault.app.ui.theme.VaultAccentSoft
import com.payvault.app.ui.theme.VaultSurfaceRaised
import com.payvault.app.util.AppUtils
import kotlinx.coroutines.launch

private val typeIcons: Map<EntryType, ImageVector> = mapOf(
    EntryType.EXPENSE to Icons.Filled.ShoppingCart,
    EntryType.LENT to Icons.Filled.MonetizationOn,
    EntryType.FAMILY to Icons.Filled.FamilyRestroom,
    EntryType.GIFT to Icons.Filled.CardGiftcard,
    EntryType.SAVING to Icons.Filled.Savings,
    EntryType.OTHER to Icons.Filled.MoreHoriz
)

private val categoryIcons: Map<String, ImageVector> = mapOf(
    "Food" to Icons.Filled.Restaurant,
    "Shopping" to Icons.Filled.ShoppingBag,
    "Fuel" to Icons.Filled.LocalGasStation,
    "Bills" to Icons.Filled.Receipt,
    "Travel" to Icons.Filled.Flight,
    "Medical" to Icons.Filled.LocalHospital,
    "Other" to Icons.Filled.Category
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntryFormScreen(
    target: HiddenApp,
    entryDao: VaultEntryDao,
    onDone: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var amountText by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(EntryType.EXPENSE) }
    var category by remember { mutableStateOf("Food") }
    var showCustomCategory by remember { mutableStateOf(false) }
    var customCategory by remember { mutableStateOf("") }
    var person by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    // --- AI Quick Entry (optional shortcut) state ---
    // Purely local text -> form-field prefill. Nothing here is submitted on its own;
    // it only edits the same state variables the manual form already uses above.
    var showQuickEntry by remember { mutableStateOf(false) }
    var quickEntryText by remember { mutableStateOf("") }
    var quickEntryFeedback by remember { mutableStateOf<String?>(null) }

    val icon = remember(target.packageName) { AppUtils.getAppIcon(context, target.packageName) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Unlock ${target.displayLabel}") },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Cancel")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            QuickEntrySection(
                expanded = showQuickEntry,
                onExpandedChange = { showQuickEntry = it },
                text = quickEntryText,
                onTextChange = {
                    quickEntryText = it
                    quickEntryFeedback = null
                },
                feedback = quickEntryFeedback,
                onFill = {
                    val parsed = QuickEntryParser.parse(quickEntryText)
                    var filledAny = false

                    parsed.amount?.let { amt ->
                        amountText = if (amt == amt.toLong().toDouble()) amt.toLong().toString() else amt.toString()
                        filledAny = true
                    }
                    parsed.type?.let { t ->
                        selectedType = t
                        filledAny = true
                    }
                    parsed.category?.let { cat ->
                        if (categoryIcons.containsKey(cat)) {
                            category = cat
                            showCustomCategory = false
                            customCategory = ""
                        } else {
                            customCategory = cat
                            category = cat
                            showCustomCategory = true
                        }
                        filledAny = true
                    }
                    parsed.person?.let { p ->
                        person = p
                        filledAny = true
                    }
                    parsed.note?.let { n ->
                        note = n
                        filledAny = true
                    }

                    error = null
                    quickEntryFeedback = if (filledAny) {
                        "Filled below \u2014 check every field, then submit."
                    } else {
                        "Couldn't pick anything out of that \u2014 fill the fields manually below."
                    }
                }
            )

            // Big, tappable-feeling amount readout — the "payment app" moment.
            AmountDisplay(amountText = amountText, error = error)

            Keypad(
                onDigit = { d ->
                    error = null
                    if (d == "." && amountText.contains(".")) return@Keypad
                    if (amountText.isEmpty() && d == ".") {
                        amountText = "0."
                    } else {
                        amountText += d
                    }
                },
                onBackspace = {
                    error = null
                    if (amountText.isNotEmpty()) amountText = amountText.dropLast(1)
                }
            )

            SectionLabel("WHAT KIND OF PAYMENT")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(EntryType.entries.toList()) { type ->
                    PillOption(
                        label = type.label,
                        icon = typeIcons[type] ?: Icons.Filled.MoreHoriz,
                        selected = selectedType == type,
                        onClick = { selectedType = type }
                    )
                }
            }

            SectionLabel("CATEGORY")
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.height(160.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(categoryIcons.keys.toList()) { cat ->
                    CategoryTile(
                        label = cat,
                        icon = categoryIcons[cat] ?: Icons.Filled.Category,
                        selected = category == cat && !showCustomCategory,
                        onClick = {
                            category = cat
                            showCustomCategory = false
                            customCategory = ""
                        }
                    )
                }
                item {
                    CategoryTile(
                        label = "Custom",
                        icon = Icons.Filled.MoreHoriz,
                        selected = showCustomCategory,
                        onClick = { showCustomCategory = true }
                    )
                }
            }

            if (showCustomCategory) {
                OutlinedTextField(
                    value = customCategory,
                    onValueChange = {
                        customCategory = it
                        category = it
                    },
                    label = { Text("Custom category") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = vaultFieldColors()
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = person,
                    onValueChange = { person = it },
                    label = { Text("Person / merchant") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = vaultFieldColors()
                )
            }
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Note (optional)") },
                modifier = Modifier.fillMaxWidth(),
                colors = vaultFieldColors()
            )

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    if (amount == null || amount <= 0.0) {
                        error = "Enter a valid amount"
                        return@Button
                    }
                    val finalCategory = if (showCustomCategory) customCategory.ifBlank { "Other" } else category

                    scope.launch {
                        entryDao.insert(
                            VaultEntry(
                                timestamp = System.currentTimeMillis(),
                                amount = amount,
                                type = selectedType,
                                category = finalCategory,
                                person = person.ifBlank { null },
                                note = note.ifBlank { null },
                                targetPackage = target.packageName,
                                targetAppLabel = target.realLabel
                            )
                        )
                        AppUtils.refreshWidgets(context)
                        // Entry is saved FIRST. Only after that do we unlock (launch) the app.
                        val launched = AppUtils.launchApp(context, target.packageName)
                        if (!launched) {
                            error = "Could not open ${target.realLabel}. It may have been uninstalled."
                        } else {
                            onDone()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VaultAccent)
            ) {
                Text("Submit & Unlock ${target.displayLabel}", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/**
 * Optional AI Quick Entry shortcut. Collapsed by default so the existing manual
 * form is unchanged by default. When expanded, it's just a text field + a button
 * that runs the local parser and copies results into the same state variables the
 * manual fields below already use — nothing here submits anything.
 */
@Composable
private fun QuickEntrySection(
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    text: String,
    onTextChange: (String) -> Unit,
    feedback: String?,
    onFill: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(VaultAccentSoft)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onExpandedChange(!expanded) },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = VaultAccent, modifier = Modifier.size(18.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("AI Quick Entry", style = MaterialTheme.typography.titleMedium, color = VaultAccent)
                if (!expanded) {
                    Text(
                        "Describe it in Hindi/Hinglish, e.g. \u201c850 petrol bharwaya\u201d",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (expanded) {
            Text(
                "Runs fully on this device \u2014 nothing is sent anywhere. Review every field before submitting.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                placeholder = { Text("e.g. \"Rahul ko 3000 udhaar diye\"") },
                modifier = Modifier.fillMaxWidth(),
                colors = vaultFieldColors()
            )
            Button(
                onClick = onFill,
                enabled = text.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VaultAccent)
            ) {
                Text("Fill fields below", fontWeight = FontWeight.Bold)
            }
            feedback?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = VaultAccent)
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun AmountDisplay(amountText: String, error: String?) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("AMOUNT", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(
            text = "\u20B9${amountText.ifEmpty { "0" }}",
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold,
            color = if (error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onBackground
        )
    }
}

@Composable
private fun Keypad(onDigit: (String) -> Unit, onBackspace: () -> Unit) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf(".", "0", "back")
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                row.forEach { key ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(2.4f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(VaultSurfaceRaised)
                            .clickable {
                                if (key == "back") onBackspace() else onDigit(key)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (key == "back") {
                            Icon(Icons.Filled.Backspace, contentDescription = "Backspace")
                        } else {
                            Text(key, style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PillOption(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) VaultAccent else VaultSurfaceRaised, label = "pillBg")
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(18.dp))
        Text(label, color = fg, style = MaterialTheme.typography.bodyMedium, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun CategoryTile(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) VaultAccentSoft else VaultSurfaceRaised, label = "catBg")
    val fg = if (selected) VaultAccent else MaterialTheme.colorScheme.onSurface
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, color = fg, maxLines = 1)
    }
}

@Composable
private fun vaultFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = VaultAccent,
    cursorColor = VaultAccent
)
