package com.payvault.app.nlp

import com.payvault.app.data.EntryType

/**
 * Result of parsing one natural-language sentence. Every field is nullable/optional —
 * the caller only overwrites form fields the parser was actually confident about, and
 * the person always reviews and can edit everything before submitting.
 */
data class ParsedEntry(
    val amount: Double? = null,
    val type: EntryType? = null,
    val category: String? = null,
    val person: String? = null,
    val note: String? = null
)

/**
 * "AI Quick Entry" parser for Hindi/Hinglish payment descriptions.
 *
 * WHY RULE-BASED, NOT A MODEL:
 * This app has no INTERNET permission and must not call any cloud AI. A genuinely
 * useful on-device *language model* (even a small quantized one) needs tens to
 * hundreds of MB of weights plus a native inference runtime (e.g. llama.cpp/GGUF,
 * MediaPipe LLM, ONNX Runtime) bundled into the APK — a huge jump in app size and
 * complexity for a feature whose whole job is "pull an amount, a type, a category
 * and a name out of one short sentence." A small dictionary + regex parser does that
 * job in well under a millisecond, adds ~10KB to the APK, needs no runtime, and is
 * trivial to audit — you can read every rule below. This matches the brief's own
 * fallback instruction: prefer a lightweight offline parser over a large model.
 *
 * This is intentionally simple pattern matching, not a statistical model — it will
 * miss unusual phrasing. That's fine: it's a shortcut that pre-fills the existing
 * form, every field stays editable, and nothing is ever submitted automatically.
 */
object QuickEntryParser {

    private val familyWords = listOf(
        "ghar", "gharwalo", "papa", "mummy", "maa", "mom", "dad", "father", "mother",
        "behen", "bhai", "sister", "brother", "wife", "husband", "beta", "beti", "family",
        "parivar"
    )
    private val lentWords = listOf(
        "udhaar", "udhar", "loan", "wapas", "karz", "karza", "lent", "borrow"
    )
    private val giftWords = listOf(
        "gift", "tohfa", "uphar", "birthday", "shagun", "gifted"
    )
    private val savingWords = listOf(
        "bachat", "saving", "savings", "invest", "investment", "fd", "rd", "sip", "jama"
    )

    /** category keyword -> display category. Order matters: first match wins. */
    private val categoryKeywords = linkedMapOf(
        "petrol" to "Fuel", "diesel" to "Fuel", "fuel" to "Fuel", "cng" to "Fuel", "gas bharwaya" to "Fuel",
        "gym" to "Gym", "fitness" to "Gym", "yoga" to "Gym",
        "fees" to "Fees", "fee" to "Fees", "school" to "Fees", "tuition" to "Fees", "college" to "Fees",
        "khana" to "Food", "food" to "Food", "restaurant" to "Food", "swiggy" to "Food",
        "zomato" to "Food", "lunch" to "Food", "dinner" to "Food", "nashta" to "Food",
        "shopping" to "Shopping", "kapde" to "Shopping", "clothes" to "Shopping", "kharidari" to "Shopping",
        "bill" to "Bills", "bijli" to "Bills", "electricity" to "Bills", "recharge" to "Bills",
        "wifi" to "Bills", "internet" to "Bills", "rent" to "Bills", "kiraya" to "Bills",
        "travel" to "Travel", "ticket" to "Travel", "bus" to "Travel", "train" to "Travel",
        "flight" to "Travel", "uber" to "Travel", "ola" to "Travel", "cab" to "Travel", "auto" to "Travel",
        "medical" to "Medical", "dawai" to "Medical", "doctor" to "Medical", "hospital" to "Medical",
        "medicine" to "Medical", "clinic" to "Medical",
        "ghar" to "Family"
    )

    fun parse(rawInput: String): ParsedEntry {
        val text = rawInput.trim()
        if (text.isEmpty()) return ParsedEntry()
        val lower = text.lowercase()

        val amount = extractAmount(lower)
        val person = extractPerson(text)
        val type = extractType(lower)
        val category = extractCategory(lower, type)
        val note = extractNote(lower)

        return ParsedEntry(
            amount = amount,
            type = type,
            category = category,
            person = person,
            note = note
        )
    }

    private fun extractAmount(lower: String): Double? {
        // "2 hazar 500", "2 hazar" -> thousands (+ optional hundreds)
        Regex("(\\d+(?:\\.\\d+)?)\\s*hazar(?:\\s+(\\d+)\\s*sau)?").find(lower)?.let { m ->
            val hazar = m.groupValues[1].toDoubleOrNull()
            if (hazar != null) {
                val sau = m.groupValues.getOrNull(2)?.toDoubleOrNull() ?: 0.0
                return hazar * 1000 + sau * 100
            }
        }
        // "5 sau" -> hundreds
        Regex("(\\d+(?:\\.\\d+)?)\\s*sau\\b").find(lower)?.let { m ->
            m.groupValues[1].toDoubleOrNull()?.let { return it * 100 }
        }
        // plain number, optionally prefixed with a currency marker: "₹850", "rs 500", "1200.50"
        Regex("(?:₹|rs\\.?|inr)?\\s*(\\d{2,7}(?:\\.\\d{1,2})?)").find(lower)?.let { m ->
            return m.groupValues[1].toDoubleOrNull()
        }
        return null
    }

    private val personStopWords = setOf("maine", "humne", "usne", "unhone", "maine to")

    /** Looks for "<Name> ko" (Hindi dative marker) — the most common "gave to X" pattern. */
    private fun extractPerson(text: String): String? {
        val match = Regex("\\b([A-Za-z]{2,})\\s+ko\\b", RegexOption.IGNORE_CASE).find(text) ?: return null
        val name = match.groupValues[1]
        if (name.lowercase() in personStopWords) return null
        return name.replaceFirstChar { it.uppercase() }
    }

    private fun extractType(lower: String): EntryType = when {
        lentWords.any { lower.contains(it) } -> EntryType.LENT
        giftWords.any { lower.contains(it) } -> EntryType.GIFT
        savingWords.any { lower.contains(it) } -> EntryType.SAVING
        familyWords.any { lower.contains(it) } -> EntryType.FAMILY
        else -> EntryType.EXPENSE
    }

    private fun extractCategory(lower: String, type: EntryType): String? {
        for ((keyword, cat) in categoryKeywords) {
            if (lower.contains(keyword)) return cat
        }
        return when (type) {
            EntryType.FAMILY -> "Family"
            EntryType.GIFT -> "Gift"
            EntryType.SAVING -> "Savings"
            else -> null // leave the form's current category untouched
        }
    }

    /** Optional: "X ke liye" (for X) is treated as a short freeform note. */
    private fun extractNote(lower: String): String? {
        val match = Regex("ke liye\\s+(.+)").find(lower) ?: return null
        val note = match.groupValues[1].trim()
        return note.ifBlank { null }
    }
}
