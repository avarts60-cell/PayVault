package com.payvault.app.nlp

import com.payvault.app.data.EntryType

/**
 * Result of parsing one shorthand Hindi/Hinglish phrase.
 *
 * amount is nullable — if no number could be found at all, the Quick Entry screen
 * declines to save rather than logging a meaningless zero-rupee entry. type and
 * category are never null: per the spec, an unclear phrase should never block or ask
 * a question, it should just fall back to the safest default (Type = Expense,
 * Category = Other) and continue.
 */
data class ParsedEntry(
    val amount: Double?,
    val type: EntryType,
    val category: String,
    val person: String?,
    val note: String?
)

/**
 * "AI Quick Entry" parser for short Hindi/Hinglish payment shorthand
 * (e.g. "500 khana", "100 Amit ko diye", "850 petrol").
 *
 * WHY RULE-BASED, NOT A MODEL:
 * The app has no INTERNET permission and must not call any cloud AI. A genuinely
 * useful on-device language model — even a small quantized one — needs a native
 * inference runtime (llama.cpp/GGUF, MediaPipe LLM, ONNX Runtime, etc.) plus tens to
 * hundreds of MB of weights bundled into the APK. That's a big jump in size and
 * complexity for a feature whose whole job is pulling five short fields out of a
 * five-word phrase. A normalization + vocabulary + rules pipeline does that in well
 * under a millisecond, adds only a few KB to the APK, needs no runtime, and is fully
 * readable below — matching the brief's own instruction to prefer a lightweight
 * offline parser over a large model when a true local model isn't practical here.
 *
 * DESIGN — normalization, then rules, in this order:
 *  1. Normalize: lowercase, strip currency symbols/commas, collapse whitespace.
 *  2. Amount: shorthand ("2k", "1.5k"), Hindi number words ("2 hazar", "5 sau"),
 *     then plain digits (optionally with an rs/inr marker).
 *  3. Person: the common Hindi dative pattern "<Name> ko".
 *  4. Type: intent keywords checked in priority order (Lent > Gift > Family >
 *     Saving), then a "<Name> ko ... diya/diye" giving pattern implies Lent, else
 *     Expense.
 *  5. Category: a keyword -> category dictionary covering common expense types and
 *     their Hindi/Hinglish spelling variants, with a type-based fallback, and Other
 *     as the final safety net — a phrase is never left uncategorized.
 */
object QuickEntryParser {

    // ---- vocabulary -------------------------------------------------------

    private val lentWords = listOf(
        "udhaar", "udhar", "udhaari", "loan", "wapas", "karz", "karza", "lent", "borrow"
    )
    private val giftWords = listOf(
        "gift", "gifted", "tohfa", "uphar", "birthday", "shaadi", "shadi", "wedding", "shagun"
    )
    private val familyWords = listOf(
        "ghar", "gharwalo", "papa", "pitaji", "mummy", "maa", "mom", "dad", "father", "mother",
        "behen", "bhai", "sister", "brother", "wife", "husband", "beta", "beti", "family", "parivar"
    )
    private val savingWords = listOf(
        "bachat", "saving", "savings", "invest", "investment", "fd", "rd", "sip", "jama"
    )
    /** "<name> ko ... X" where X is one of these implies money changed hands (Lent). */
    private val giveVerbs = listOf(
        "diya", "diye", "di", "de diya", "de di", "dega", "degi", "dunga", "dungi", "doonga"
    )

    /**
     * keyword (Hindi/Hinglish, incl. common spelling variants) -> display category.
     * Scanned in order; the first keyword found in the phrase wins, so more specific
     * terms (e.g. "gym") are listed before more generic ones (e.g. "fees").
     */
    private val categoryKeywords = linkedMapOf(
        // fuel
        "petrol" to "Fuel", "diesel" to "Fuel", "fuel" to "Fuel", "cng" to "Fuel",
        // fitness (checked before the generic "fees"/"fee" entries below)
        "gym" to "Fitness", "fitness" to "Fitness", "yoga" to "Fitness",
        // education
        "school" to "Education", "tuition" to "Education", "college" to "Education",
        "exam" to "Education", "education" to "Education",
        // books & stationery
        "kitab" to "Books", "kitaab" to "Books", "kitaabein" to "Books", "book" to "Books",
        "books" to "Books", "copy" to "Stationery", "stationery" to "Stationery",
        "pen" to "Stationery", "pencil" to "Stationery",
        // food
        "khana" to "Food", "khaana" to "Food", "food" to "Food", "restaurant" to "Food",
        "swiggy" to "Food", "zomato" to "Food", "lunch" to "Food", "dinner" to "Food",
        "nashta" to "Food", "hotel" to "Food",
        // groceries
        "doodh" to "Grocery", "dhoodh" to "Grocery", "dudh" to "Grocery", "sabzi" to "Grocery",
        "sabji" to "Grocery", "grocery" to "Grocery", "groceries" to "Grocery", "kirana" to "Grocery",
        "fruits" to "Grocery", "fruit" to "Grocery", "vegetables" to "Grocery",
        // shopping
        "kapde" to "Shopping", "kapada" to "Shopping", "clothes" to "Shopping",
        "shopping" to "Shopping", "kharidari" to "Shopping", "dress" to "Shopping",
        // recharge / mobile / internet
        "recharge" to "Recharge", "topup" to "Recharge", "top-up" to "Recharge", "mobile" to "Recharge",
        "internet" to "Internet", "wifi" to "Internet", "broadband" to "Internet",
        // bills / utilities / rent
        "bijli" to "Electricity", "electricity" to "Electricity",
        "bill" to "Bills", "bills" to "Bills",
        "rent" to "Rent", "kiraya" to "Rent",
        // fees (generic, after gym/school-specific ones above)
        "fees" to "Education", "fee" to "Education",
        // medical
        "dawai" to "Medical", "dawaai" to "Medical", "medicine" to "Medical", "medicines" to "Medical",
        "doctor" to "Medical", "hospital" to "Medical", "clinic" to "Medical",
        // travel
        "ticket" to "Travel", "bus" to "Travel", "train" to "Travel", "flight" to "Travel",
        "uber" to "Travel", "ola" to "Travel", "cab" to "Travel", "auto" to "Travel", "travel" to "Travel",
        // entertainment
        "movie" to "Entertainment", "cinema" to "Entertainment", "netflix" to "Entertainment",
        "entertainment" to "Entertainment", "party" to "Entertainment",
        // household / family (keyword form; type-level "ghar" also drives Type below)
        "household" to "Household", "ghar" to "Family"
    )

    // ---- entry point --------------------------------------------------------

    fun parse(rawInput: String): ParsedEntry {
        val normalized = normalize(rawInput)
        if (normalized.isEmpty()) {
            return ParsedEntry(amount = null, type = EntryType.EXPENSE, category = "Other", person = null, note = null)
        }

        val amount = extractAmount(normalized)
        val person = extractPerson(normalized)
        val type = extractType(normalized, person)
        val category = extractCategory(normalized, type)

        return ParsedEntry(
            amount = amount,
            type = type,
            category = category,
            person = person,
            note = null
        )
    }

    private fun normalize(rawInput: String): String {
        return rawInput
            .trim()
            .lowercase()
            .replace(Regex("[₹,]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    // ---- amount ---------------------------------------------------------

    private fun extractAmount(text: String): Double? {
        // "2k", "1.5k" -> thousands
        Regex("(\\d+(?:\\.\\d+)?)\\s*k\\b").find(text)?.let { m ->
            m.groupValues[1].toDoubleOrNull()?.let { return it * 1000 }
        }
        // "2 hazar 500" / "2 hazaar" -> thousands (+ optional hundreds)
        Regex("(\\d+(?:\\.\\d+)?)\\s*hazaa?r(?:\\s+(\\d+)\\s*sau)?").find(text)?.let { m ->
            val hazar = m.groupValues[1].toDoubleOrNull()
            if (hazar != null) {
                val sau = m.groupValues.getOrNull(2)?.toDoubleOrNull() ?: 0.0
                return hazar * 1000 + sau * 100
            }
        }
        // "5 sau" -> hundreds
        Regex("(\\d+(?:\\.\\d+)?)\\s*sau\\b").find(text)?.let { m ->
            m.groupValues[1].toDoubleOrNull()?.let { return it * 100 }
        }
        // plain number, optionally with rs/inr marker (currency symbols already stripped in normalize())
        Regex("(?:rs\\.?|inr)?\\s*(\\d{1,7}(?:\\.\\d{1,2})?)").find(text)?.let { m ->
            return m.groupValues[1].toDoubleOrNull()
        }
        return null
    }

    // ---- person -----------------------------------------------------------

    private val personStopWords = setOf("maine", "humne", "usne", "unhone")

    /** "<Name> ko" — the common Hindi dative marker for "to <person>". */
    private fun extractPerson(text: String): String? {
        val match = Regex("\\b([a-z]{2,})\\s+ko\\b").find(text) ?: return null
        val name = match.groupValues[1]
        if (name in personStopWords) return null
        return name.replaceFirstChar { it.uppercase() }
    }

    // ---- type ---------------------------------------------------------------

    private fun extractType(text: String, person: String?): EntryType = when {
        lentWords.any { text.contains(it) } -> EntryType.LENT
        giftWords.any { text.contains(it) } -> EntryType.GIFT
        familyWords.any { text.contains(it) } -> EntryType.FAMILY
        savingWords.any { text.contains(it) } -> EntryType.SAVING
        // "Amit ko ... diye" with no other keyword -> money given to a person = Lent
        person != null && giveVerbs.any { text.contains(it) } -> EntryType.LENT
        else -> EntryType.EXPENSE
    }

    // ---- category -------------------------------------------------------

    private fun extractCategory(text: String, type: EntryType): String {
        for ((keyword, cat) in categoryKeywords) {
            if (text.contains(keyword)) return cat
        }
        return when (type) {
            EntryType.FAMILY -> "Family"
            EntryType.GIFT -> "Gift"
            EntryType.SAVING -> "Savings"
            // Lent/Expense with no recognizable keyword: safest default per spec.
            else -> "Other"
        }
    }
}
