package com.payvault.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

/** The fixed set of "where did this money go" buckets, as specified. */
enum class EntryType(val label: String) {
    EXPENSE("Expense"),
    LENT("Lent"),
    FAMILY("Family"),
    GIFT("Gift"),
    SAVING("Saving"),
    OTHER("Other")
}

/** Suggested categories. The category field itself is free text, so users can type anything. */
object SuggestedCategories {
    val defaults = listOf("Food", "Shopping", "Fuel", "Bills", "Travel", "Medical", "Other")
}

/**
 * One logged intent: "I'm about to pay ₹X for Y reason." Written BEFORE the target
 * app is unlocked. Nothing about the actual payment (success, amount charged, UPI ref,
 * etc.) is ever recorded — this app has no way to see that.
 */
@Entity(tableName = "vault_entries")
data class VaultEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,          // System.currentTimeMillis() at submit time
    val amount: Double,
    val type: EntryType,
    val category: String,
    val person: String?,          // optional person/merchant
    val note: String?,            // optional note
    val targetPackage: String?,   // which app this entry unlocked (null until the Quick
                                   // Entry flow's "choose app" step assigns it)
    val targetAppLabel: String?   // real app label, for history display
)

/** A payment app the user has chosen to route through the vault. */
@Entity(tableName = "hidden_apps")
data class HiddenApp(
    @PrimaryKey val packageName: String,
    val realLabel: String,
    val displayLabel: String,     // what the vault shows for this tile; defaults to realLabel,
                                   // user can rename it to something generic if they want
    val addedAt: Long
)

class Converters {
    @TypeConverter
    fun fromEntryType(type: EntryType): String = type.name

    @TypeConverter
    fun toEntryType(value: String): EntryType = EntryType.valueOf(value)
}
