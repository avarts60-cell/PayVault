# PayVault

A local, offline "friction gate" for your payment apps. Instead of a PIN, you type
what the payment is for — the app then unlocks (launches) the real payment app for
you to complete the payment manually.

## What it does

1. You pick which apps (PhonePe, GPay, Paytm, ...) live behind the vault.
2. Tapping a vault tile opens a form: **Amount, Type, Category, Person/Merchant
   (optional), Note (optional)**.
3. On Submit, the entry is saved locally, then the real app is launched — the same
   as tapping its own icon.
4. PayVault does nothing else. It doesn't watch the screen, read notifications,
   access your bank, or know whether the payment happened.
5. A Monthly view shows totals, spend by type, category breakdown, top categories,
   and full transaction history — all computed from what you typed in, nothing else.

## What it deliberately does NOT do

- No `INTERNET` permission at all — the app *cannot* send data anywhere, by
  construction, not just by promise.
- No accessibility service, no notification listener, no usage-stats access, no
  device-admin/MDM APIs.
- No reading of the target app's UI, clipboard, notifications, or storage.
- No verification that a payment actually happened — it can't know, and doesn't try.

## Important: the real limitation on "hiding" apps

Android does **not** let a normal app hide another app's home-screen icon or
app-drawer entry. That capability is restricted to:
- The device's **default launcher** (a full launcher replacement app), or
- **Device-owner / MDM** provisioning (`DevicePolicyManager.setApplicationHidden`),
  which requires enterprise device management setup — not realistic for a personal
  phone.

PayVault is a normal app, not a launcher replacement, so it uses the closest
practical, fully-supported approach instead:

- **PayVault becomes the front door.** You add PhonePe/GPay/etc. as vault tiles.
  PayVault launches them via the standard public launch-intent API
  (`PackageManager.getLaunchIntentForPackage`) — identical to tapping their icon.
- **You manually remove the payment apps' icons from your home screen** (drag to
  "Remove from Home", not uninstall) after adding them to the vault, and access them
  only through PayVault going forward. Many launchers (Nova, Samsung One UI, MIUI)
  also have a native "Hide apps" feature in their own settings — if yours does, use
  that for the app-drawer entry too. This is a manual one-time step; no code can do
  it for you from inside a regular app.
- **Optional: disguise PayVault itself.** `AndroidManifest.xml` includes a commented-out
  `activity-alias` example that lets PayVault change *its own* icon/label (e.g. to
  look like "Notes"). This only touches PayVault's own components via the public
  `PackageManager.setComponentEnabledSetting` API — see `AppUtils.setDisguiseEnabled()`.
- **Recents/App-switcher:** after a payment app is launched, consider swiping it away
  from Recents when done, since a screenshot of it may still appear there — this is
  normal OS behavior for any app and not something PayVault can suppress for another app.

If true system-wide icon hiding matters more to you than the "type before you pay"
gate, the next step up would be building a full launcher replacement (a much bigger
project — happy to scope that separately if you want it).

## What's new: real UI + home-screen widgets

**UI overhaul.** The form-fill flow is unchanged conceptually, but it no longer looks
like a form:
- A dark "vault" theme (custom color scheme in `ui/theme/Theme.kt`) instead of default
  Material colors.
- Vault tiles show the **real app icon** (read via the public `PackageManager` icon API
  — same icon you'd see on your home screen).
- The entry screen has a big amount readout with its own **number keypad**, animated
  icon "pill" buttons for Type, and an icon grid for Category — closer to a payment
  app's own UI than a settings form.
- The Monthly view now has an actual **progress-bar breakdown by type** and a **donut
  chart** for top categories, drawn with Compose `Canvas`, alongside the transaction list.

**Two home-screen widgets**, built with Jetpack Glance so they share the same data
(Room) as the app:
- **Quick Unlock** — lists up to 4 vault apps; tapping one opens PayVault straight at
  that app's entry form (skipping the tile grid). It never launches the payment app
  itself from the widget — you still have to fill in and submit the form first, so the
  gate isn't bypassed.
- **Monthly Total** — shows this month's running total and top category at a glance;
  tapping it opens the dashboard.

Both widgets refresh automatically right after you save an entry or add an app
(`AppUtils.refreshWidgets()` is called at those points) — no background polling, no
`updatePeriodMillis`, so there's no periodic wake-up battery cost.

To add them: long-press your home screen → Widgets → PayVault → drag either widget out.

## Project structure

```
PayVault/
  app/src/main/java/com/payvault/app/
    MainActivity.kt          – entry point, simple screen-state navigation
    data/Models.kt            – VaultEntry & HiddenApp Room entities, EntryType enum
    data/Daos.kt               – Room DAOs
    data/AppDatabase.kt        – Room database singleton (local file, payvault.db)
    util/AppUtils.kt          – list launchable apps, launch an app, app icons, disguise, widget refresh
    ui/theme/Theme.kt          – dark vault color scheme & typography
    ui/VaultHomeScreen.kt     – tile grid of hidden apps (real icons, month stat header)
    ui/AddHiddenAppScreen.kt  – picker to add an installed app to the vault
    ui/EntryFormScreen.kt     – the core gate: keypad + icon pills/grid → unlock
    ui/DashboardScreen.kt     – monthly totals, by-type bars, category donut chart, history
    widget/QuickUnlockWidget.kt      – Glance widget: jump straight to an app's form
    widget/MonthlySummaryWidget.kt   – Glance widget: this month's total + top category
```

## Building it

1. Open the `PayVault/` folder in Android Studio (Koala or newer).
2. Let Gradle sync (it will download Compose, Room, KSP — first sync needs internet
   just for Gradle/Maven, the *app itself* never uses network at runtime).
3. Run on a device/emulator with API 26+.
4. First run: tap **+** on the home screen, search for PhonePe/GPay/Paytm, tap Add.
5. Remove those apps' icons from your actual home screen (see limitation above).
6. From then on, open PayVault → tap the app tile → fill the form → Submit → the real
   app opens.

## Data

Everything is stored in a local Room/SQLite database (`payvault.db`) inside the app's
private storage. `android:allowBackup="false"` and explicit `data_extraction_rules.xml`
exclusions mean it's also never swept into Android's automatic cloud backup.

There's currently no export/delete-all UI — easy to add if you want CSV export for the
monthly view or a "wipe all data" button; just ask.
