package com.payvault.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultEntryDao {
    @Insert
    suspend fun insert(entry: VaultEntry): Long

    @Delete
    suspend fun delete(entry: VaultEntry)

    @Query("SELECT * FROM vault_entries ORDER BY timestamp DESC")
    fun getAll(): Flow<List<VaultEntry>>

    @Query("SELECT * FROM vault_entries WHERE timestamp BETWEEN :start AND :end ORDER BY timestamp DESC")
    fun getForRange(start: Long, end: Long): Flow<List<VaultEntry>>
}

@Dao
interface HiddenAppDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(app: HiddenApp)

    @Delete
    suspend fun delete(app: HiddenApp)

    @Query("UPDATE hidden_apps SET displayLabel = :label WHERE packageName = :pkg")
    suspend fun renameDisplayLabel(pkg: String, label: String)

    @Query("SELECT * FROM hidden_apps ORDER BY addedAt ASC")
    fun getAll(): Flow<List<HiddenApp>>
}
