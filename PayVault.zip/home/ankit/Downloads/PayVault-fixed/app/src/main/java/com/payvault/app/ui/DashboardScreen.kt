package com.payvault.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.payvault.app.data.EntryType
import com.payvault.app.data.VaultEntry
import com.payvault.app.data.VaultEntryDao
import com.payvault.app.ui.theme.VaultAccent
import com.payvault.app.ui.theme.VaultSurfaceRaised
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val chartPalette = listOf(
    Color(0xFF34D399), Color(0xFF60A5FA), Color(0xFFFBBF24),
    Color(0xFFF472B6), Color(0xFFA78BFA), Color(0xFFFB923C), Color(0xFF94A3B8)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    entryDao: VaultEntryDao,
    onBack: () -> Unit
) {
    var monthOffset by remember { mutableStateOf(0) }

    val cal = remember(monthOffset) {
        Calendar.getInstance().apply {
            add(Calendar.MONTH, monthOffset)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }
    val start = cal.timeInMillis
    val end = remember(start) {
        Calendar.getInstance().apply {
            timeInMillis = start
            add(Calendar.MONTH, 1)
        }.timeInMillis - 1
    }
    val monthLabel = remember(start) {
        SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(start))
    }

    val entries by entryDao.getForRange(start, end).collectAsState(initial = emptyList())

    val total = entries.sumOf { it.amount }
    val byType = EntryType.entries.associateWith { type -> entries.filter { it.type == type }.sumOf { it.amount } }
    val byCategory = entries.groupBy { it.category }
        .mapValues { (_, list) -> list.sumOf { it.amount } }
        .toList()
        .sortedByDescending { it.second }
    val topCategories = byCategory.take(6)

    val currency = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Monthly view") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = { monthOffset -= 1 }) {
                        Icon(Icons.Filled.ChevronLeft, contentDescription = "Previous month")
                    }
                    Text(monthLabel, style = MaterialTheme.typography.titleLarge)
                    IconButton(onClick = { if (monthOffset < 0) monthOffset += 1 }) {
                        Icon(Icons.Filled.ChevronRight, contentDescription = "Next month")
                    }
                }
            }

            item {
                VaultCard {
                    Text("Total logged", style = MaterialTheme.typography.labelLarge, color = VaultAccent)
                    Text(currency.format(total), style = MaterialTheme.typography.headlineMedium)
                    Text("${entries.size} entries this month", style = MaterialTheme.typography.bodySmall)
                }
            }

            item {
                VaultCard {
                    Text("By type", style = MaterialTheme.typography.labelLarge, color = VaultAccent)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        byType.forEach { (type, amount) ->
                            if (amount > 0) {
                                TypeBar(label = type.label, amount = amount, max = byType.values.maxOrNull() ?: 1.0, currency = currency)
                            }
                        }
                    }
                }
            }

            item {
                VaultCard {
                    Text("Top spending categories", style = MaterialTheme.typography.labelLarge, color = VaultAccent)
                    if (topCategories.isEmpty()) {
                        Text("No entries yet.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        CategoryDonut(topCategories, currency)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            topCategories.forEachIndexed { i, (cat, amount) ->
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row {
                                        LegendDot(chartPalette[i % chartPalette.size])
                                        Text(cat, modifier = Modifier.padding(start = 6.dp))
                                    }
                                    Text(currency.format(amount), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text("Transaction history", style = MaterialTheme.typography.titleMedium)
            }

            if (entries.isEmpty()) {
                item { Text("No entries logged this month.", style = MaterialTheme.typography.bodySmall) }
            } else {
                items(entries, key = { it.id }) { entry ->
                    TransactionRow(entry, currency)
                    Divider(color = VaultSurfaceRaised)
                }
            }
        }
    }
}

@Composable
private fun VaultCard(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content
        )
    }
}

@Composable
private fun TypeBar(label: String, amount: Double, max: Double, currency: NumberFormat) {
    val fraction = if (max <= 0.0) 0f else (amount / max).toFloat().coerceIn(0f, 1f)
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(currency.format(amount), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(VaultSurfaceRaised)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth(fraction)
                    .fillMaxSize()
                    .background(VaultAccent)
            ) {}
        }
    }
}

@Composable
private fun CategoryDonut(data: List<Pair<String, Double>>, currency: NumberFormat) {
    val total = data.sumOf { it.second }
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
    ) {
        val strokeWidth = 26.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = androidx.compose.ui.geometry.Offset(
            (size.width - diameter) / 2f,
            (size.height - diameter) / 2f
        )
        var startAngle = -90f
        data.forEachIndexed { i, (_, amount) ->
            val sweep = if (total <= 0.0) 0f else (amount / total * 360.0).toFloat()
            drawArc(
                color = chartPalette[i % chartPalette.size],
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = androidx.compose.ui.geometry.Size(diameter, diameter),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Butt)
            )
            startAngle += sweep
        }
    }
}

@Composable
private fun LegendDot(color: Color) {
    Canvas(
        modifier = Modifier
            .padding(top = 5.dp)
            .height(10.dp)
            .width(10.dp)
    ) {
        drawCircle(color = color, radius = size.minDimension / 2f)
    }
}

@Composable
private fun TransactionRow(entry: VaultEntry, currency: NumberFormat) {
    val dateFmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }
    ListItem(
        headlineContent = { Text("${entry.category} \u00b7 ${entry.type.label}") },
        supportingContent = {
            val details = buildString {
                append(entry.targetAppLabel)
                entry.person?.let { append(" \u00b7 $it") }
                entry.note?.let { append(" \u00b7 $it") }
            }
            Text("${dateFmt.format(Date(entry.timestamp))} \u00b7 $details", style = MaterialTheme.typography.bodySmall)
        },
        trailingContent = {
            Text(currency.format(entry.amount), fontWeight = FontWeight.Bold)
        },
        colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.background)
    )
}
