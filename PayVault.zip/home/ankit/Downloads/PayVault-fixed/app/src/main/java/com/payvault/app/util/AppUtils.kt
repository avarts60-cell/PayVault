package com.payvault.app.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.glance.appwidget.updateAll

data class LaunchableApp(val packageName: String, val label: String)

object AppUtils {

    /**
     * Lists apps that have a normal home-screen launcher entry, the same set you'd see
     * in the app drawer. Uses only the standard MAIN/LAUNCHER intent query declared in
     * the manifest's <queries> block — no QUERY_ALL_PACKAGES, no hidden APIs.
     */
    fun getLaunchableApps(context: Context): List<LaunchableApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val ownPackage = context.packageName

        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolved
            .asSequence()
            .map { it.activityInfo }
            .filter { it.packageName != ownPackage }
            .map { info ->
                val label = try {
                    info.loadLabel(pm).toString()
                } catch (_: Exception) {
                    info.packageName
                }
                LaunchableApp(info.packageName, label)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    /**
     * Loads the target app's real launcher icon so vault tiles/widgets can show it
     * instead of a generic placeholder. Read-only use of the public PackageManager
     * icon API — same icon you'd see on the home screen. Returns null if the app
     * can't be resolved (e.g. uninstalled since being added to the vault).
     */
    fun getAppIcon(context: Context, packageName: String): ImageBitmap? {
        return try {
            val drawable: Drawable = context.packageManager.getApplicationIcon(packageName)
            val width = drawable.intrinsicWidth.coerceAtLeast(1)
            val height = drawable.intrinsicHeight.coerceAtLeast(1)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            bitmap.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Launches another app's normal launch Activity — exactly the same effect as the
     * user tapping that app's own home-screen icon. This app does not attach to, read
     * from, or control the target app in any way afterwards.
     */
    fun launchApp(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    /**
     * OPTIONAL: flips PayVault's own launcher icon between its normal identity and the
     * disguised activity-alias defined (commented out) in AndroidManifest.xml. This only
     * ever touches THIS app's own components via the public
     * PackageManager.setComponentEnabledSetting API — it cannot enable/disable/hide any
     * other app's icon. Left inactive by default; wire up a Settings toggle to use it.
     */
    /**
     * Tells the home-screen widgets to redraw with fresh data. Call this after
     * inserting a VaultEntry or changing the hidden-apps list. Cheap and local —
     * just re-runs the same Room queries the widgets already use.
     */
    suspend fun refreshWidgets(context: Context) {
        com.payvault.app.widget.QuickUnlockWidget().updateAll(context)
        com.payvault.app.widget.MonthlySummaryWidget().updateAll(context)
    }

    fun setDisguiseEnabled(context: Context, enabled: Boolean) {
        val pm = context.packageManager
        val mainActivity = ComponentName(context, "com.payvault.app.MainActivity")
        val alias = ComponentName(context, "com.payvault.app.DisguiseAlias")

        pm.setComponentEnabledSetting(
            mainActivity,
            if (enabled) PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            else PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            alias,
            if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}
