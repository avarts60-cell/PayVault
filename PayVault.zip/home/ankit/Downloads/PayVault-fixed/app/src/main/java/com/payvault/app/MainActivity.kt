package com.payvault.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import kotlinx.coroutines.flow.first
import com.payvault.app.data.AppDatabase
import com.payvault.app.data.HiddenApp
import com.payvault.app.ui.AddHiddenAppScreen
import com.payvault.app.ui.DashboardScreen
import com.payvault.app.ui.EntryFormScreen
import com.payvault.app.ui.VaultHomeScreen
import com.payvault.app.ui.theme.PayVaultTheme

/** Which screen is currently showing. Deliberately simple — no nav library needed for 4 screens. */
sealed class Screen {
    data object Home : Screen()
    data object AddApp : Screen()
    data class EntryForm(val target: HiddenApp) : Screen()
    data object Dashboard : Screen()
}

class MainActivity : ComponentActivity() {

    companion object {
        /** Set by the "Quick Unlock" home-screen widget to jump straight to a given app's form. */
        const val EXTRA_TARGET_PACKAGE = "com.payvault.app.EXTRA_TARGET_PACKAGE"
    }

    private var pendingTargetPackage by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingTargetPackage = intent?.getStringExtra(EXTRA_TARGET_PACKAGE)
        val db = AppDatabase.get(applicationContext)

        setContent {
            PayVaultTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(db = db, deepLinkPackage = pendingTargetPackage, onDeepLinkConsumed = { pendingTargetPackage = null })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingTargetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE)
    }
}

@Composable
fun AppRoot(db: AppDatabase, deepLinkPackage: String?, onDeepLinkConsumed: () -> Unit) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    // A widget tap arrives as a package name, not a HiddenApp — resolve it from Room
    // and jump straight to the entry form, skipping the tile grid entirely.
    LaunchedEffect(deepLinkPackage) {
        val pkg = deepLinkPackage ?: return@LaunchedEffect
        // getAll() is a Flow; take the first emitted list to resolve once.
        val apps = db.hiddenAppDao().getAll().first()
        apps.firstOrNull { it.packageName == pkg }?.let {
            screen = Screen.EntryForm(it)
        }
        onDeepLinkConsumed()
    }

    when (val s = screen) {
        is Screen.Home -> VaultHomeScreen(
            hiddenAppDao = db.hiddenAppDao(),
            entryDao = db.vaultEntryDao(),
            onAddApp = { screen = Screen.AddApp },
            onOpenDashboard = { screen = Screen.Dashboard },
            onTileTap = { app -> screen = Screen.EntryForm(app) }
        )

        is Screen.AddApp -> AddHiddenAppScreen(
            hiddenAppDao = db.hiddenAppDao(),
            onDone = { screen = Screen.Home }
        )

        is Screen.EntryForm -> EntryFormScreen(
            target = s.target,
            entryDao = db.vaultEntryDao(),
            onDone = { screen = Screen.Home }
        )

        is Screen.Dashboard -> DashboardScreen(
            entryDao = db.vaultEntryDao(),
            onBack = { screen = Screen.Home }
        )
    }
}
