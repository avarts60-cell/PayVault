package com.payvault.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NoEncryption
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.payvault.app.data.HiddenApp
import com.payvault.app.data.HiddenAppDao
import com.payvault.app.data.VaultEntryDao
import com.payvault.app.ui.theme.VaultAccent
import com.payvault.app.ui.theme.VaultAccentSoft
import com.payvault.app.ui.theme.VaultSurfaceRaised
import com.payvault.app.util.AppUtils
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultHomeScreen(
    hiddenAppDao: HiddenAppDao,
    entryDao: VaultEntryDao,
    onAddApp: () -> Unit,
    onOpenDashboard: () -> Unit,
    onTileTap: (HiddenApp) -> Unit
) {
    val apps by hiddenAppDao.getAll().collectAsState(initial = emptyList())

    val monthStart = monthStartMillis()
    val entries by entryDao.getForRange(monthStart, Long.MAX_VALUE).collectAsState(initial = emptyList())
    val monthTotal = entries.filter { it.timestamp >= monthStart }.sumOf { it.amount }
    val currency = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("PayVault", style = MaterialTheme.typography.titleLarge)
                        Text("Tap an app to unlock it", style = MaterialTheme.typography.bodySmall)
                    }
                },
                actions = {
                    IconButton(onClick = onOpenDashboard) {
                        Icon(Icons.Filled.Insights, contentDescription = "Monthly view", tint = VaultAccent)
                    }
                    IconButton(onClick = onAddApp) {
                        Icon(Icons.Filled.Add, contentDescription = "Add app to vault", tint = VaultAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(MaterialTheme.colorScheme.background, Color(0xFF141830))
                    )
                )
        ) {
            if (apps.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Filled.NoEncryption,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("Vault is empty", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Tap + to add PhonePe, GPay, Paytm, etc.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        MonthStatHeader(total = monthTotal, currency = currency, onClick = onOpenDashboard)
                    }
                    item {
                        Text(
                            "VAULT",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                        )
                    }
                    items(apps, key = { it.packageName }) { app ->
                        AppTile(app = app, onClick = { onTileTap(app) })
                    }
                }
            }
        }
    }
}

private fun monthStartMillis(): Long {
    val cal = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
}

@Composable
private fun MonthStatHeader(total: Double, currency: NumberFormat, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = VaultAccentSoft),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("This month", style = MaterialTheme.typography.labelLarge, color = VaultAccent)
                Spacer(Modifier.height(4.dp))
                Text(currency.format(total), style = MaterialTheme.typography.headlineMedium)
            }
            Icon(Icons.Filled.Insights, contentDescription = null, tint = VaultAccent, modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
private fun AppTile(app: HiddenApp, onClick: () -> Unit) {
    val context = LocalContext.current
    val icon = produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, key1 = app.packageName) {
        value = AppUtils.getAppIcon(context, app.packageName)
    }.value

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = VaultSurfaceRaised),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                if (icon != null) {
                    Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(30.dp))
                } else {
                    Text(app.displayLabel.take(1).uppercase(), style = MaterialTheme.typography.titleMedium)
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(app.displayLabel, style = MaterialTheme.typography.titleMedium)
                Text("Locked \u00b7 tap to unlock", style = MaterialTheme.typography.bodySmall)
            }
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Lock, contentDescription = "Locked", tint = VaultAccent, modifier = Modifier.size(18.dp))
            }
        }
    }
}
