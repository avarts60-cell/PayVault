package com.payvault.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// A dark "vault" palette — deep navy/charcoal base with a single confident
// mint-green accent, rather than default Material purple. Deliberately
// restrained: one accent color, used consistently, reads as premium rather
// than "default app template".
val VaultBackground = Color(0xFF0F1220)
val VaultSurface = Color(0xFF181C2E)
val VaultSurfaceRaised = Color(0xFF222842)
val VaultAccent = Color(0xFF34D399)      // mint green
val VaultAccentSoft = Color(0xFF1F3A34)
val VaultText = Color(0xFFF3F4F8)
val VaultTextMuted = Color(0xFF9BA0B4)
val VaultDanger = Color(0xFFF87171)

val VaultColorScheme = darkColorScheme(
    primary = VaultAccent,
    onPrimary = Color(0xFF03281D),
    secondary = VaultAccent,
    background = VaultBackground,
    onBackground = VaultText,
    surface = VaultSurface,
    onSurface = VaultText,
    surfaceVariant = VaultSurfaceRaised,
    onSurfaceVariant = VaultTextMuted,
    error = VaultDanger
)

val VaultTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 28.sp, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 13.sp, letterSpacing = 0.4.sp),
    bodyLarge = TextStyle(fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    bodySmall = TextStyle(fontSize = 12.sp, color = VaultTextMuted)
)

@Composable
fun PayVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VaultColorScheme,
        typography = VaultTypography,
        content = content
    )
}
