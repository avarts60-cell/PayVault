package com.payvault.app.widget

import android.content.Context
import android.content.Intent
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.clickable
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.payvault.app.MainActivity
import com.payvault.app.data.AppDatabase
import kotlinx.coroutines.flow.first
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private val WidgetBackground = ColorProvider(0xFF0F1220.toInt())
private val WidgetAccent = ColorProvider(0xFF34D399.toInt())
private val WidgetText = ColorProvider(0xFFF3F4F8.toInt())
private val WidgetMuted = ColorProvider(0xFF9BA0B4.toInt())

/**
 * A tiny widget showing this month's logged total and the top category, computed
 * purely from entries you've already typed in — same source data as the in-app
 * dashboard, nothing new is inferred or tracked.
 */
class MonthlySummaryWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        val entries = AppDatabase.get(context).vaultEntryDao().getForRange(start, Long.MAX_VALUE).first()

        val total = entries.sumOf { it.amount }
        val topCategory = entries.groupBy { it.category }
            .mapValues { (_, list) -> list.sumOf { it.amount } }
            .maxByOrNull { it.value }

        val currency = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        val monthLabel = SimpleDateFormat("MMM", Locale.getDefault()).format(cal.time)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        provideContent {
            Column(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .background(WidgetBackground)
                    .padding(14.dp)
                    .clickable(actionStartActivity(intent))
            ) {
                Text("$monthLabel spend", style = TextStyle(color = WidgetMuted))
                Text(
                    currency.format(total),
                    style = TextStyle(color = WidgetAccent, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                )
                if (topCategory != null) {
                    Text(
                        "Top: ${topCategory.key}",
                        style = TextStyle(color = WidgetText)
                    )
                }
            }
        }
    }
}

class MonthlySummaryWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = MonthlySummaryWidget()
}
